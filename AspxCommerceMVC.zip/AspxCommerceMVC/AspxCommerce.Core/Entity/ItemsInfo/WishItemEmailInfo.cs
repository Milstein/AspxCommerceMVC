﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AspxCommerce.Core
{
    public class WishItemEmailInfo
    {

        public string src { get; set; }
        public string alt { get; set; }
        public string title { get; set; }
        public string price { get; set; }
        public string href { get; set; }
        public string hrefHtml { get; set; }
        public string htmlComment { get; set; }
    }
}

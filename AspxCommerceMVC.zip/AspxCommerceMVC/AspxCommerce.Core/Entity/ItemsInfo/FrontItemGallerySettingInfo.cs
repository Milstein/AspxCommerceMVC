﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AspxCommerce.Core
{
   public class FrontItemGallerySettingInfo
    {
       public string GalleryDisplayAs { get; set; }
       public int Count { get; set; }
    }
}

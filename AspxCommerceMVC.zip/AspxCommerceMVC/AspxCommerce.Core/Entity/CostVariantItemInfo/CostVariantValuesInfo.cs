﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AspxCommerce.Core
{
   public  class CostVariantValuesInfo
    {
       public int CostVariantsValueID { get; set; }
       public string CostVariantsValueName { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AspxCommerce.Core.Entity.WareHouse
{
    public class CommonShipmentInfo
    {

        //private Address _FromAddress;
        //public Address FromAddress
        //{
        //    get { return _FromAddress; }
        //    set { _FromAddress = value; }
        //}
        //private Address _ToAddress;
        //public Address ToAddress
        //{
        //    get { return _ToAddress; }
        //    set { _ToAddress = value; }
        //}
        //private decimal _WeightInOunces;
        //public decimal WeightInOunces
        //{
        //    get { return _WeightInOunces; }
        //    set { _WeightInOunces = value; }
        //}
        //private string _Option;
        //public string Option
        //{
        //    get { return _Option; }
        //    set { _Option = value; }
        //}
        //private ServiceType _ServiceType;
        //public ServiceType ServiceType
        //{
        //    get { return _ServiceType; }
        //    set { _ServiceType = value; }
        //}
        //private string _POZipCode;
        //public string POZipCode
        //{
        //    get { return _POZipCode; }
        //    set { _POZipCode = value; }
        //}
        //private ImageType _ImageType;
        //public ImageType ImagaType
        //{
        //    get { return _ImageType; }
        //    set { _ImageType = value; }
        //}
        //private DateTime _LabelDate;
        //public DateTime LabelDate
        //{
        //    get { return _LabelDate; }
        //    set { _LabelDate = value; }
        //}

        //private bool _AddressServiceRequested;
        //public bool AddressServiceRequested
        //{
        //    get { return _AddressServiceRequested; }
        //    set { _AddressServiceRequested = value; }
        //}
        //private bool _SeparateReceiptPage = false;

        //public bool SeparateReceiptPage
        //{
        //    get { return _SeparateReceiptPage; }
        //    set { _SeparateReceiptPage = value; }
        //}
    }
}

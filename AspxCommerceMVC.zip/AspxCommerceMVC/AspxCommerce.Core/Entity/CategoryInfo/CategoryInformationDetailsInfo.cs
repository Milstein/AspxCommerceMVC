﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AspxCommerce.Core
{
    public class CategoryInformationDetailsInfo
    {
        public string CategoryName { get; set; }
        public string ShortDescription { get; set; }
        public string Description { get; set; }
        public string IsService { get; set; }
        public string CategoryItems { get; set; }
    }
}

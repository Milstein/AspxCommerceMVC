﻿
namespace AspxCommerce.GoogleCheckOut
{
    public class GoogleCheckOutSupportedCurrency
    {
        public static string googleCheckOutSupportedCurrency = "USD,GBP";
    }
}

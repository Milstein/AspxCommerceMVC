﻿namespace AspxCommerce.PayPal
{
   public class PaypalSupportedCurrency
    {
        public static string paypalSupportedCurrency = "AUD,BRL,CAD,CZK,DKK,EUR,HKD,HUF,ILS,JPY,MYR,MXN,NOK,NZD,PHP,PLN,GBP,SGD,SEK,CHF,TWD,THB,TRY,USD";
    }
}

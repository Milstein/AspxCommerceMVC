﻿
namespace AspxCommerce.Moneybookers
{
    public class MoneybookersSupportedCurrency
    {
        public static string moneybookersSupportedCurrency = "EUR,TWD,USD,THB,GBP,CZK,HKD,HUF,SGD,SKK,JPY,EEK,CAD,BGN,AUD,PLN,CHF,ISK,DKK,INR,SEK,LVL,NOK,KRW,ILS,ZAR,MYR,RON,NZD,HRK,TRY,LTL,AED,JOD,MAD,OMR,QAR,RSD,SAR,TND";
    }
}
